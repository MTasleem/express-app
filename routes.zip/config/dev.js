module.exports = {
    mongoURI: "mongodb+srv://test123:test123@testcluster-qitcd.mongodb.net/slave-dev?retryWrites=true&w=majority",
    port: 5000
}